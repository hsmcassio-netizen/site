function mostrarConteudo(tipo) {

    const conteudoDiv = document.getElementById('conteudo');
    let html = '';

    switch (tipo) {
        case 'inicio':
            html = `
                <div class="pagina-inicial">
                    <img src="imagens/Foto da Escola.png"width="300" height="400"  alt="Foto da Escola" class="foto-escola">
                    <h2>Bem-Vindo à Escola Estadual Dom Jayme</h2>
                    <p> <div class="marquee-container">
        <div id="marquee-text">📢 Bem-vindos à Escola Estadual Dom Jayme de Barros Câmara! Confira nossos projetos e novidades no mural. 📢</div>
      </div></p>
                </div>
            `;
            break;
             case 'Nossa história':
            html = 
            ` <h2 style="text-align:center; margin-bottom:15px;">CONHEÇA NOSSA HISTÓRIA</h2>
      <div class="mural-fundo"><p li style="margin: 10px 0; text-align: center;"><img src="imagens/DOMJAYME.png"width="180" height="220" alt="" style="width: "1"; height: "2"; object-fit: cover; margin: auto; display: block;"p/>
            <p style="text-align: center;"><strong> Dom Jayme de Barros Câmara (São José, 3 de julho de 1894 – Aparecida, 18 de fevereiro de 1971)</strong></p>
            <p style="text-align: justify;">Dom Jayme de Barros Câmara (São José, 3 de julho de 1894 – Aparecida, 18 de fevereiro de 1971) foi um cardeal brasileiro de ascendência açoriana e madeirense.
           Era filho legítimo do segundo matrimônio do Escrivão de Órfãos Joaquim Xavier de Oliveira Câmara, nascido em 1856 em São José (SC), com Anna de Carvalho Barros, nascida em 1864 em Salvador (BA). Era descendente direto por linha paterna de João Gonçalves Zarco, desbravador da Ilha da Madeira.
	Fez seus estudos eclesiásticos no Seminário de São Leopoldo, Rio Grande do Sul. 
	Foi ordenado sacerdote no dia 1º de janeiro de 1920, em Florianópolis, pelas mãos de Dom Joaquim  Domingues de Oliveira. Atuou na Arquidiocese de Florianópolis, Santa Catarina no período de 1920 a 1930. Foi reitor do Seminário Nossa Senhora de Lourdes Azambuja-Brusque e do Santuário de Nossa Senhora do Caravaggio de Azambuja de 1927 a 1936. No dia 18 de abril de 1935 foi nomeado camareiro secreto de Sua Santidade, pelo Papa Pio XI, passando a usar o título de Monsenhor.
	No dia 19 de dezembro de 1935 Monsenhor Jayme de Barros Câmara foi nomeado pelo Papa Pio XI 1º bispo da Diocese de Mossoró, Rio Grande do Norte, criada no dia 28 de julho de 1934. Sua ordenação episcopal foi em Florianópolis, no dia 2 de fevereiro de 1936, pelas mãos do Dom Joaquim Domingues de Oliveira, Dom Pio de Freitas Silveira, CM, Dom Daniel Henrique Hostin, OFM.
	No dia 15 de setembro de 1941, o Papa Pio XII nomeia Dom Jayme  Arcebispo de Belém do Pará. A posse do novo arcebispo aconteceu no dia 1 de janeiro de 1942. Durante seu governo na Arquidiocese de Belém do Pará promoveu a reforma dos estudos do Seminário, adquiriu o Colégio Progresso Paraense (atual colégio Santa Maria de Belém), a sede do Círculo Operário e o Seminário Ferial (atual Centro de Treinamento Tabor, em Icoaraci).
	Dom Jayme foi designado pelo Papa Pio XII para a Arquidiocese de São Sebastião do Rio de Janeiro no dia 3 de julho de 1943, tomou posse no dia 15 de setembro deste mesmo ano. Deu grande apoio ao estabelecimento de igrejas orientais no Brasil, por exemplo, ao erigir paróquia a Igreja de São Basílio, Greco- católica melquita, que ele mesmo definiu como “joia rara”.
	No Consistório do dia 18 de fevereiro de 1946, presidido pelo Papa Pio XII, Dom Jayme de Barros Câmara foi criado cardeal com o título dos Santos Bonifácio e Aleixo, do qual tomou posse solenemente no dia 22 de fevereiro do mesmo ano. Neste consistório foi também criado cardeal o brasileiro Carlos Carmelo Cardeal de Vasconcelos Motta.
	Foi ao legado papal no Congresso Eucarístico Nacional, realizado em Porto Alegre, Rio Grande do Sul, em outubro de 1948; ao Congresso Interamericano da Confederação da Educação Católica, no Rio de Janeiro em 1951; ao Congresso Eucarístico Nacional, em Curitiba, Paraná, em março de 1960.
	Dom Jayme foi nomeado ordinário militar no dia 6 de novembro de 1950, permanecendo na função até 9 de novembro de 1963.
	O Cardeal Barros Câmara foi designado ordinário para os fiéis de rito oriental no dia 14 de novembro de 1951. Participou da Primeira Conferência Geral do Episcopado Latino-Americano, realizada no Rio de Janeiro, em 1955. Foi presidente da Conferência Nacional dos Bispos do Brasil (CNBB) , no período de 1958 a 1963.
	Participou do conclave de 1958 que elegeu o Papa João XXII e do conclave de 1963 que elegeu o Papa Paulo VI. Participou de todas as sessões do Concílio Vaticano II.
	Dom Jayme de Barros Câmara foi o primeiro bispo de Mossoró, teve como sucessor a Dom Antônio de Almeida Lustosa, SDB, e teve como sucessor Dom Mário de Miranda Vilas- Boas.
	Sua Eminência foi o quarto Arcebispo de São Sebastião do Rio de Janeiro, sucedeu a Dom Sebastião Leme  Cardeal da Silveira Cintra e foi sucedido por Dom Eugênio Cardeal de Araújo Sales. Faleceu em Aparecida, São Paulo, dia 18 de fevereiro de 1971, aos 76 anos de idade. Foi sepultado na nova Catedral do Rio de Janeiro.
	Menos de um mês depois da sua morte, o Diário Oficial do Estado publicava, no dia 12 de março de 1971, o decreto que dizia: “Passa a denominar-se Colégio Estadual Dom Jayme de Barros Câmara o “Colégio do Município de Sumaré”.

<p style="text-align: justify;"> Histórico de criação:GINÁSIO ESTADUAL DE SUMARÉ : Lei nº 3.801/57
COLÉGIO ESTADUAL DE SUMARÉ : Decreto nº 52.582/70
COLÉGIO ESTADUAL COM JAYME DE BARROS CÂMARA : Decreto de 11/03/1971</p>

<p style="text-align: justify;">A Escola Estadual de Ensino Médio Integral Dom Jayme de Barros Câmara, é uma escola tradicional, situada na região central de Sumaré. Aderiu ao Programa Ensino Integral em 2013. O Programa orienta-se pelo referencial que explicita o compromisso da formação integral dos adolescentes e jovens. Para isso, o Modelo Pedagógico do Programa Ensino Integral deve consolidar um conjunto de metodologias dirigidas a essa formação integral, com estímulos ao desenvolvimento das potencialidades dos estudantes, à ampliação de suas perspectivas de autorrealização, e ao exercício de uma cidadania autônoma, solidária e competente. Desde então tem tido grande aceitação da comunidade, gerando inclusive, fila de espera para vagas. Esta procura por vagas tem sido intensificada devido a relatos, por parte de pais e estudantes, do trabalho desenvolvido pela equipe, boa qualidade de ensino e ampla formação do cidadão.
As ações propostas pelas metodologias associadas ao Modelo Pedagógico, são todas pautadas pelo princípio do Protagonismo Juvenil e têm como objetivo formar jovens autônomos, solidários e competentes, com oferta de espaços de vivências durante o período escolar para que os próprios estudantes possam buscar a realização das suas potencialidades pessoais e sociais como se desenham, ano a ano, nos seus respectivos Projetos de Vida.</p>



 <table border="1" cellpadding="5" cellspacing="0">
                <tr>
                    <th>Curso</th>
                    <th>Série / Ano</th>
                    <th>Horários de atendimento</th>
                    <th>Ato de autorização/criação (DOE)</th>
                </tr>
                <tr>
                    <td>Ensino Médio Escola de Tempo Integral</td>
                    <td>1ª à 3ª</td>
                    <td>07:30h – 16:30h</td>
                    <td>Resolução nº 345 de 12 em 13/12/1984</td>
                </tr>
                <tr>
                    <td>Centro de Estudos de Línguas</td>
                    <td>Espanhol/Inglês</td>
                    <td>07:00h – 10:20h<br>13:50h – 17:20h</td>
                    <td>Decreto nº 27.270 de 10/08/1987 e Decreto nº 44.449 de 24/11/1999</td>
                </tr>
                <tr>
                    <td>Sala de Recursos para Deficientes Visuais</td>
                    <td>Ensino Fundamental e Médio</td>
                    <td>Manhã/Tarde</td>
                    <td>Resolução 11, de 31/01/2008</td>
                </tr>
                <tr>
                    <td>Novotec Integrado - Técnico em Administração</td>
                    <td>2ª série A e 3ª série A</td>
                    <td>07:30h – 11:45h</td>
                    <td>Resolução SEDUC nº 86, de 20-09-2021</td>
                </tr>
            </table>
</p>`
;
            break;
    case 'equipe':
    html = `
        <h2 style="text-align: center;">EQUIPE ESCOLAR </h2>
 
        <ul style="list-style: none; padding: 0;">
          <li style="margin: 10px 0; text-align: center;">
              <img src="professores/regis.png"width="140" height="180" alt="Foto de Reginaldo Cremonesi Torres" style="width: "1"; height: "2"; object-fit: cover; margin: auto; display: block;">
            <p style="font-weight: bold;">Reginaldo Cremonesi Torres</p>
            <p>Diretor Escolar</p>
          </li>
          <li style="margin: 10px 0; text-align: center;">
             <img src="professores/gio.png"width="140" height="180" alt="Foto de Reginaldo Cremonesi Torres" style="width: "1"; height: "2"; object-fit: cover; margin: auto; display: block;">
            <p style="font-weight: bold;">Giovanni Aparecido de Sousa</p>
            <p>Vice-Diretor Escolar</p>
          </li>
          <li style="margin: 10px 0; text-align: center;">
            <img src="professores/vera.png"width="140" height="180" alt="Foto de Reginaldo Cremonesi Torres" style="width: "1"; height: "2"; object-fit: cover; margin: auto; display: block;">
            <p style="font-weight: bold;">Vera Aparecida Rodrigues</p>
            <p>Coordenadora de Gestão Pedagógica Geral</p>
          </li>
          <li style="display: flex; justify-content: space-around; margin: 20px 0;">
            <div style="text-align: center;">
              <img src="professores/wagner.png"width="140" height="180" alt="Foto de Reginaldo Cremonesi Torres" style="width: "1"; height: "2"; object-fit: cover; margin: auto; display: block;">
              <p style="font-weight: bold;">Wagner Willian Guarato</p>
              <p>CGPAC - Ciências da Natureza</p>
            </div>
            <div style="text-align: center;">
              <img src="professores/rafa.png"width="140" height="180" alt="Foto de Reginaldo Cremonesi Torres" style="width: "1"; height: "2"; object-fit: cover; margin: auto; display: block;">
              <p style="font-weight: bold;">Rafaela Falcão</p>
              <p>CGPAC - Linguagens</p>
            </div>
            <div style="text-align: center;">
              <img src="professores/fabricio.png"width="140" height="180" alt="Foto de Reginaldo Cremonesi Torres" style="width: "1"; height: "2"; object-fit: cover; margin: auto; display: block;">
              <p style="font-weight: bold;">Fabrício Ribeiro da Silva</p>
              <p>CGPAC - Humanas</p>
            </div>
          </li>
        </ul>
      </div> <p>CONHEÇA NOSSA EQUIPE DE PROFESSORES <button onclick="window.location.href='professores.html'" target="_blank">Clique aqui</button></p>';
    `;
    break;
        case 'Feira de Ciências-DJTEC':
            html = '<h2 style="text-align:center; margin-bottom:15px;">DJTEC - MOSTRA CULTURAL E CIENTIFICA</h2><p style="text-align:center; margin-bottom:15px;"><img src="imagens/BANNER.png"width="700" height="300"  alt="Foto da Escola" class="foto-escola"></p>';
            break;
             case 'Sala de Recursos Para Deficiêntes Visuais':
            html = '<h2 style="text-align:center; margin-bottom:15px;"> SRDV - SALA DE RECURSOS PARA DEFICIENTES VISUAIS</h2><p style="text-align:center; margin-bottom:15px;"><img src=""width="700" height="300"  alt="Foto da Escola" class="foto-escola"></p>';
            break;
             case 'cel':
            html = '<h2 style="text-align:center; margin-bottom:15px;">  CEL - CENTRO DE ESTUDO DE LINGUAS</h2><p style="text-align:center; margin-bottom:15px;"><img src=""width="700" height="300"  alt="Foto da Escola" class="foto-escola"></p>';
            break;
        case 'infra':
            html =  
            
            '<h2 style="text-align: center;">INFRAESTRUTURA</h2><p style="text-align: justify;">A Escola Estadual Dom Jaime de Barros Câmara é uma instituição de ensino integral comprometida com a formação completa dos seus estudantes, aliando excelência acadêmica, inclusão e desenvolvimento humano. Com uma estrutura moderna que inclui laboratórios de Física, Química, Biologia e Matemática, sala de leitura, biblioteca, núcleo de educação para deficiência visual e um Centro de Estudos de Línguas (CEL), a escola oferece também o curso técnico em Administração, ampliando as possibilidades de formação dos alunos.</p><p style="text-align: justify;">Alinhada ao Programa de Ensino Integral (PEI), a escola adota uma proposta pedagógica que promove o desenvolvimento pleno do estudante por meio de uma educação que vai além do conteúdo escolar tradicional. Com base em princípios humanistas e democráticos, o ensino integral valoriza quatro pilares fundamentais: a educação integral, que considera todas as dimensões do ser humano; o protagonismo juvenil, incentivando os alunos a assumirem papéis ativos em suas trajetórias; o projeto de vida, como ferramenta de autoconhecimento e planejamento pessoal e profissional; e o apoio à aprendizagem, garantindo acompanhamento pedagógico individualizado e o uso de metodologias inovadoras</p><p style="text-align: justify;">Além disso, o ensino integral parte de premissas como a formação cidadã, a valorização das competências socioemocionais, a gestão participativa, a inclusão e o currículo flexível, que dialoga com as realidades e interesses dos estudantes. Com essa proposta, a Escola Estadual Dom Jaime de Barros Câmara busca formar cidadãos éticos, autônomos e preparados para os desafios da vida, do mundo do trabalho e da convivência em sociedade.</p><img src="infraestrutura/biblioteca.jpg"width="340" height="300">&nbsp &nbsp &nbsp;<img src="infraestrutura/quadra.jpg"width="340" height="300">&nbsp &nbsp &nbsp;<img src="infraestrutura/teclado.jpg"width="340" height="300"><p><img src="infraestrutura/casinha.jpg"width="340" height="300">&nbsp &nbsp &nbsp;<img src="infraestrutura/lab seco.jpg"width="340" height="300">&nbsp &nbsp &nbsp<img src="infraestrutura/hall.jpeg"width="340" height="300"></p><p><img src="infraestrutura/cozinha.jpeg"width="340" height="300">&nbsp &nbsp &nbsp<img src="infraestrutura/jardim.jpeg"width="340" height="300">&nbsp &nbsp &nbsp<img src="infraestrutura/labquimica.jpeg"width="340" height="300"></P><p><img src="infraestrutura/maker.jpeg"width="340" height="300">&nbsp &nbsp &nbsp<img src="infraestrutura/palco.jpeg"width="340" height="300">&nbsp &nbsp &nbsp<img src="infraestrutura/refeitorio.jpeg"width="340" height="300"></img><p><img src="infraestrutura/volei.jpeg"width="340" height="300">&nbsp &nbsp &nbsp<img src="infraestrutura/aula.jpeg"width="340" height="300">&nbsp &nbsp &nbsp<img src="infraestrutura/sala.jpeg"width="340" height="300"></img>';
          
            break;
        case 'noticias':
            html = '<h2>Notícias e Eventos</h2><p>EM BREVE</p>';
            break;
      case 'Monitoramento de Plataformas':
    html = `
        <h2 style="text-align:center; margin-bottom:15px;">MONITORAMENTO DE PLATAFORMAS - 25 DE AGOSTO DE 2025</h2>
        <table border="1" cellspacing="0" cellpadding="8" style="width:100%; text-align:center; border-collapse:collapse; font-size:14px;">
            <thead>
                <tr style="background:#f2f2f2;">
                    <th>Série</th>
                    <th>Aluno Presente</th>
                    <th>Leia SP</th>
                    <th>Redação Paulista</th>
                    <th>Tarefas</th>
                    <th>Microbit</th>
                    <th>Speak</th>
                    <th>Prepara SP</th>
                    <th>Khan Academy</th>
                    <th>Alura</th>
                </tr>
            </thead>
            <tbody>
                <tr>
                    <td>1ºA</td>
                    <td><img src="imagens/vermelho.png" width="28"></td>
                    <td><img src="imagens/amarelo.png" width="28"></td>
                    <td><img src="imagens/vermelho.png" width="28"></td>
                    <td><img src="imagens/verde.png" width="28"></td>
                    <td><img src="imagens/amarelo.png" width="28"></td>
                    <td><img src="imagens/verde.png" width="28"></td>
                    <td><img src="imagens/vermelho.png" width="28"></td>
                    <td><img src="imagens/amarelo.png" width="28"></td>
                    <td><img src="imagens/verde.png" width="28"></td>
                </tr>
                <tr>
                    <td>1ºB</td>
                    <td><img src="imagens/amarelo.png" width="28"></td>
                    <td><img src="imagens/verde.png" width="28"></td>
                    <td><img src="imagens/amarelo.png" width="28"></td>
                    <td><img src="imagens/vermelho.png" width="28"></td>
                    <td><img src="imagens/verde.png" width="28"></td>
                    <td><img src="imagens/amarelo.png" width="28"></td>
                    <td><img src="imagens/vermelho.png" width="28"></td>
                    <td><img src="imagens/verde.png" width="28"></td>
                    <td><img src="imagens/amarelo.png" width="28"></td>
                </tr>
                <tr>
                    <td>1ºC</td>
                    <td><img src="imagens/verde.png" width="28"></td>
                    <td><img src="imagens/vermelho.png" width="28"></td>
                    <td><img src="imagens/amarelo.png" width="28"></td>
                    <td><img src="imagens/verde.png" width="28"></td>
                    <td><img src="imagens/amarelo.png" width="28"></td>
                    <td><img src="imagens/vermelho.png" width="28"></td>
                    <td><img src="imagens/verde.png" width="28"></td>
                    <td><img src="imagens/amarelo.png" width="28"></td>
                    <td><img src="imagens/verde.png" width="28"></td>
                </tr>
                <tr>
                    <td>2ºA</td>
                    <td><img src="imagens/vermelho.png" width="28"></td>
                    <td><img src="imagens/verde.png" width="28"></td>
                    <td><img src="imagens/amarelo.png" width="28"></td>
                    <td><img src="imagens/verde.png" width="28"></td>
                    <td><img src="imagens/vermelho.png" width="28"></td>
                    <td><img src="imagens/amarelo.png" width="28"></td>
                    <td><img src="imagens/verde.png" width="28"></td>
                    <td><img src="imagens/verde.png" width="28"></td>
                    <td><img src="imagens/amarelo.png" width="28"></td>
                </tr>
                <tr>
                    <td>2ºB</td>
                    <td><img src="imagens/amarelo.png" width="28"></td>
                    <td><img src="imagens/vermelho.png" width="28"></td>
                    <td><img src="imagens/verde.png" width="28"></td>
                    <td><img src="imagens/amarelo.png" width="28"></td>
                    <td><img src="imagens/verde.png" width="28"></td>
                    <td><img src="imagens/vermelho.png" width="28"></td>
                    <td><img src="imagens/verde.png" width="28"></td>
                    <td><img src="imagens/amarelo.png" width="28"></td>
                    <td><img src="imagens/vermelho.png" width="28"></td>
                </tr>
                <tr>
                    <td>2ºC</td>
                    <td><img src="imagens/verde.png" width="28"></td>
                    <td><img src="imagens/amarelo.png" width="28"></td>
                    <td><img src="imagens/vermelho.png" width="28"></td>
                    <td><img src="imagens/verde.png" width="28"></td>
                    <td><img src="imagens/amarelo.png" width="28"></td>
                    <td><img src="imagens/vermelho.png" width="28"></td>
                    <td><img src="imagens/amarelo.png" width="28"></td>
                    <td><img src="imagens/verde.png" width="28"></td>
                    <td><img src="imagens/vermelho.png" width="28"></td>
                </tr>
                <tr>
                    <td>3ºA</td>
                    <td><img src="imagens/vermelho.png" width="28"></td>
                    <td><img src="imagens/verde.png" width="28"></td>
                    <td><img src="imagens/amarelo.png" width="28"></td>
                    <td><img src="imagens/vermelho.png" width="28"></td>
                    <td><img src="imagens/verde.png" width="28"></td>
                    <td><img src="imagens/amarelo.png" width="28"></td>
                    <td><img src="imagens/vermelho.png" width="28"></td>
                    <td><img src="imagens/amarelo.png" width="28"></td>
                    <td><img src="imagens/verde.png" width="28"></td>
                </tr>
                <tr>
                    <td>3ºB</td>
                    <td><img src="imagens/verde.png" width="28"></td>
                    <td><img src="imagens/amarelo.png" width="28"></td>
                    <td><img src="imagens/vermelho.png" width="28"></td>
                    <td><img src="imagens/verde.png" width="28"></td>
                    <td><img src="imagens/amarelo.png" width="28"></td>
                    <td><img src="imagens/verde.png" width="28"></td>
                    <td><img src="imagens/vermelho.png" width="28"></td>
                    <td><img src="imagens/amarelo.png" width="28"></td>
                    <td><img src="imagens/verde.png" width="28"></td>
                </tr>
                <tr>
                    <td>3ºC</td>
                    <td><img src="imagens/vermelho.png" width="28"></td>
                    <td><img src="imagens/verde.png" width="28"></td>
                    <td><img src="imagens/amarelo.png" width="28"></td>
                    <td><img src="imagens/vermelho.png" width="28"></td>
                    <td><img src="imagens/verde.png" width="28"></td>
                    <td><img src="imagens/vermelho.png" width="28"></td>
                    <td><img src="imagens/amarelo.png" width="28"></td>
                    <td><img src="imagens/verde.png" width="28"></td>
                    <td><img src="imagens/amarelo.png" width="28"></td>
                </tr>
            </tbody>
        </table>
    `;
    break;


        case 'projetos':
            html = `
                 <h2 style="text-align:center; margin-bottom:15px;">PROJETOS DESENVOLVIDOS NA ESCOLA</h2>
      <div class="mural-fundo">
        <table class="mural-tabela">
          <tr>
            <td>
              <a href="https://www.youtube.com/watch?v=dQw4w9WgXcQ" target="_blank">
                <img src="projetos/DJTEC.jpeg" alt="Projeto 01" />
                <p>PROJETO 01 – FEIRA DE CIÊNCIAS</p>
              </a>
            </td>
            <td>
              <a href="https://www.youtube.com/watch?v=eY52Zsg-KVI" target="_blank">
                <img src="projetos/3M.jpeg" alt="Projeto 02" />
                <p>PROJETO 02 – FEBRACE</p>
              </a>
            </td>
            <td>
              <a href="https://www.youtube.com/watch?v=9bZkp7q19f0" target="_blank">
                <img src="projetos/AGITA.jpeg" alt="Projeto 03" />
                <p>PROJETO 03 – AGITA GALERA</p>
              </a>
            </td>
            <td>
              <a href="https://www.youtube.com/watch?v=kXYiU_JCYtU" target="_blank">
                <img src="projetos/DIADAAGUA.jpeg" alt="Projeto 04" />
                <p>PROJETO 04 – DIA DA ÁGUA</p>
              </a>
            </td>
                    </tr>

         <td>
              <a href="https://www.youtube.com/watch?v=kXYiU_JCYtU" target="_blank">
                <img src="projetos/CERA.jpeg" alt="Projeto 04" />
                <p>PROJETO 05 – CERAMANA CERAMINA</p>
              </a>
            </td>
             <td>
              <a href="https://www.youtube.com/watch?v=kXYiU_JCYtU" target="_blank">
                <img src="projetos/CASA SUSTENTAVEL.jpeg" alt="Projeto 04" />
                <p>PROJETO 06 – CASA SUSTENTÁVEL</p>
              </a>
            </td>
             <td>
              <a href="https://www.youtube.com/watch?v=kXYiU_JCYtU" target="_blank">
                <img src="projetos/CHA.jpeg" alt="Projeto 04" />
                <p>PROJETO 07 – CHA LITERÁRIO</p>
              </a>
            </td>
             <td>
              <a href="https://www.youtube.com/watch?v=kXYiU_JCYtU" target="_blank">
                <img src="projetos/INSGHT.jpeg" alt="Projeto 04" />
                <p>PROJETO 08 – ÓCULOS PARA DEFICIENTE VISUAL</p>
              </a>
            </td>
             </tr>

         <td>
              <a href="https://www.youtube.com/watch?v=kXYiU_JCYtU" target="_blank">
                <img src="projetos/OBAFOG.jpeg" alt="Projeto 04" />
                <p>PROJETO 09 – MOSTRA BRASILEIRA DE FOGUETES OLLA</p>
              </a>
            </td>
             <td>
              <a href="https://www.youtube.com/watch?v=kXYiU_JCYtU" target="_blank">
                <img src="projetos/OBA.jpeg" alt="Projeto 04" />
                <p>PROJETO 10 – DIA DA ÁGUA</p>
              </a>
            </td>
             <td>
              <a href="https://www.youtube.com/watch?v=kXYiU_JCYtU" target="_blank">
                <img src="projetos/MATA.jpeg" alt="Projeto 04" />
                <p>PROJETO 11 – DIA DA ÁGUA</p>
              </a>
            </td>
             <td>
              <a href="https://www.youtube.com/watch?v=kXYiU_JCYtU" target="_blank">
                <img src="projetos/DIADAMATEMATICA.jpeg" alt="Projeto 04" />
                <p>PROJETO 12 – DIA DA ÁGUA</p>
              </a>
            </td>
             </tr>

         <td>
              <a href="https://www.youtube.com/watch?v=kXYiU_JCYtU" target="_blank">
                <img src="projetos/OBB.jpeg" alt="Projeto 04" />
                <p>PROJETO 13 – DIA DA ÁGUA</p>
              </a>
            </td>
             <td>
              <a href="https://www.youtube.com/watch?v=kXYiU_JCYtU" target="_blank">
                <img src="projetos/MIATECH.jpeg" alt="Projeto 04" />
                <p>PROJETO 14 – DIA DA ÁGUA</p>
              </a>
            </td>
             <td>
              <a href="https://www.youtube.com/watch?v=kXYiU_JCYtU" target="_blank">
                <img src="projetos/OBMEP.jpeg" alt="Projeto 04" />
                <p>PROJETO 15 – DIA DA ÁGUA</p>
              </a>
            </td>
             <td>
              <a href="https://www.youtube.com/watch?v=kXYiU_JCYtU" target="_blank">
                <img src="projetos/OMASP.jpeg" alt="Projeto 04" />
                <p>PROJETO 16 – DIA DA ÁGUA</p>
              </a>
            </td>
             </tr>

         <td>
              <a href="https://www.youtube.com/watch?v=kXYiU_JCYtU" target="_blank">
                <img src="projetos/NOVEMBRO.jpeg" alt="Projeto 04" />
                <p>PROJETO 17 – DIA DA ÁGUA</p>
              </a>
            </td>
             <td>
              <a href="https://www.youtube.com/watch?v=kXYiU_JCYtU" target="_blank">
                <img src="projetos/OUTUBRO.jpeg" alt="Projeto 04" />
                <p>PROJETO 18 – DIA DA ÁGUA</p>
              </a>
            </td>
             <td>
              <a href="https://www.youtube.com/watch?v=kXYiU_JCYtU" target="_blank">
                <img src="projetos/SEECOL.jpeg" alt="Projeto 04" />
                <p>PROJETO 19 – DIA DA ÁGUA</p>
              </a>
            </td>
             <td>
              <a href="https://www.youtube.com/watch?v=kXYiU_JCYtU" target="_blank">
                <img src="projetos/RESPOSTA.jpeg" alt="Projeto 04" />
                <p>PROJETO 20 – DIA DA ÁGUA</p>
              </a>
            </td>
              </tr>

         <td>
              <a href="https://www.youtube.com/watch?v=kXYiU_JCYtU" target="_blank">
                <img src="projetos/SOLETRANDO.jpeg" alt="Projeto 04" />
                <p>PROJETO 21 – DIA DA ÁGUA</p>
              </a>
            </td>
             <td>
              <a href="https://www.youtube.com/watch?v=kXYiU_JCYtU" target="_blank">
                <img src="projetos/UPA.jpeg" alt="Projeto 04" />
                <p>PROJETO 22 – DIA DA ÁGUA</p>
              </a>
            </td>
             <td>
              <a href="https://www.youtube.com/watch?v=kXYiU_JCYtU" target="_blank">
                <img src="projetos/STEM.jpeg" alt="Projeto 04" />
                <p>PROJETO 23 – DIA DA ÁGUA</p>
              </a>
            </td>
             <td>
              <a href="https://www.youtube.com/watch?v=kXYiU_JCYtU" target="_blank">
                <img src="projetos/ZOO.jpeg" alt="Projeto 04" />
                <p>PROJETO 24 – DIA DA ÁGUA</p>
              </a>
            </td>
  </tr>

         <td>
              <a href="https://www.youtube.com/watch?v=kXYiU_JCYtU" target="_blank">
                <img src="projetos/WORDCAFE.jpeg" alt="Projeto 04" />
                <p>PROJETO 25 – DIA DA ÁGUA</p>
              </a>
            </td>
             <td>
              <a href="https://www.youtube.com/watch?v=kXYiU_JCYtU" target="_blank">
                <img src="projetos/OUTUBRO.jpeg" alt="Projeto 04" />
                <p>PROJETO 26 – DIA DA ÁGUA</p>
              </a>
            </td>
             <td>
              <a href="https://www.youtube.com/watch?v=kXYiU_JCYtU" target="_blank">
                <img src="projetos/SEECOL.jpeg" alt="Projeto 04" />
                <p>PROJETO 27 – DIA DA ÁGUA</p>
              </a>
            </td>
             <td>
              <a href="https://www.youtube.com/watch?v=kXYiU_JCYtU" target="_blank">
                <img src="projetos/RESPOSTA.jpeg" alt="Projeto 04" />
                <p>PROJETO 27 – DIA DA ÁGUA</p>
              </a>
            </td>
    `;
    break;
      case 'laboratorio':
    html = `
      <h2 style="text-align:center; margin-bottom:15px;"> Laboratórios</h2>
      <div class="mural-labs">
        <div class="lab-item">
          <img src="imagens/fisica.jpg" alt="Laboratório de Física">
          <p>Laboratório de Física</p>
        </div>
        <div class="lab-item">
          <img src="imagens/quimica.jpg" alt="Laboratório de Química">
          <p>Laboratório de Química</p>
        </div>
        <div class="lab-item">
          <img src="imagens/biologia.jpg" alt="Laboratório de Biologia">
          <p>Laboratório de Biologia</p>
        </div>
        <div class="lab-item">
          <img src="imagens/matematica.jpg" alt="Laboratório de Matemática">
          <p>Laboratório de Matemática</p>
        </div>
      </div>
    `;
    break;

        case 'Mural de Evidências':
              html = `
      <h2 style="text-align:center; margin-bottom:15px;">MURAL DE EVIDÊNCIAS</h2><div style="text-align:center; margin-bottom:15px;">
          <input type="file" id="uploadFoto" accept="image/*" />
          <input type="text" id="tituloFoto" placeholder="Digite um título" style="padding:5px; margin-left:5px;" />
          <button onclick="enviarFoto()">Adicionar</button>
      </div>
      <table class="mural-tabela" id="catalogoFotos"></table>
    `;

    setTimeout(() => {
        carregarFotos();

        window.enviarFoto = function() {
            const fileInput = document.getElementById('uploadFoto');
            const tituloInput = document.getElementById('tituloFoto');

            if (!fileInput.files[0]) {
                alert("Escolha uma imagem!");
                return;
            }

            const formData = new FormData();
            formData.append("foto", fileInput.files[0]);
            formData.append("titulo", tituloInput.value);

            fetch("upload.php", {
                method: "POST",
                body: formData
            })
            .then(r => r.text())
            .then(res => {
                if (res.includes("SUCESSO")) {
                    carregarFotos();
                    fileInput.value = "";
                    tituloInput.value = "";
                } else {
                    alert("Erro ao enviar!");
                }
            });
        };

        window.carregarFotos = function() {
            fetch("listar.php")
                .then(r => r.json())
                .then(lista => {
                    const tabela = document.getElementById("catalogoFotos");
                    tabela.innerHTML = "";

                    let tr;
                    lista.forEach((item, i) => {
                        if (i % 4 === 0) {
                            tr = document.createElement("tr");
                            tabela.appendChild(tr);
                        }
                        const td = document.createElement("td");
                        td.innerHTML = `
                            <a href="${item.arquivo}" target="_blank">
                                <img src="${item.arquivo}" alt="${item.titulo}" style="width:120px;height:160px;object-fit:cover;border-radius:8px;" />
                                <p>${item.titulo}</p>
                            </a>
                        `;
                        tr.appendChild(td);
                    });
                });
        };
    }, 100);
    break;
        default:
            html = `
                <div class="pagina-inicial">
                    <img src="imagens/foto-escola.jpg" alt="Foto da Escola" class="foto-escola">
                    <h2>Bem-Vindo à Escola Estadual Dom Jayme</h2>
                    <p>Selecione uma opção no menu ao lado para ver mais informações.</p>
                </div>
            `;
    }

    conteudoDiv.innerHTML = html;
}
window.onload = function() {
    mostrarConteudo('inicio');
};